from netbuilder.builder import build_configs

# Entry point script
build_configs()
