import intf_data

def build_configs():
    for site in intf_data.sites_list:
        print(f"\nConfiguring Site {site}")

        for sw in intf_data.sw_list:
            print(f"\nConfiguring {sw}")

            for item in intf_data.intf_conf_data:
                print(intf_data.intf_syntax["intf_name"].format(item["intf_name"]))
                print(intf_data.intf_syntax["desc"].format(item["desc"]))
                print(intf_data.intf_syntax["speed"].format(item["speed"]))
                print(intf_data.intf_syntax["duplex"].format(item["duplex"]))

if __name__ == "__main__":
    build_configs()
